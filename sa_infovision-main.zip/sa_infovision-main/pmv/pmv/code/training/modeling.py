import joblib
from os.path import dirname, join, realpath
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline


class MultiNB:
    def __init__(self, model_path="../../pmv/model/"):
        # load the sentiment model
        with open(join(model_path, "sentiment_model_pipeline.pkl"), "rb") as f:
            self.model = joblib.load(f)

    def predict(self, text):
        """
        param:
        text: str
        """
        prediction = self.model.predict([text])
        probas = self.model.predict_proba([text])

        # show results
        result = {
            "prediction": "Negative" if prediction[0] == "P" else "Positive",
            "Probability": probas[:, 0][0] if prediction[0] == "P" else probas[:, 1][0],
        }
        print(result)
        return result
