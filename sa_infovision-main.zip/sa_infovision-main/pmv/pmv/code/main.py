import os
import re
from string import punctuation
import joblib
import uvicorn
from fastapi import FastAPI
from training.modeling import MultiNB

app = FastAPI(
    title="Sentiment Model API",
    description="for comment sentiments",
    version="0.1",
)


# cleaning the comment
def get_clean_comment(comment):
    comment = re.sub(r"[^A-Za-z0-9]", " ", comment)
    comment = re.sub(r"\'s", " ", comment)
    comment = re.sub(r"http\S+", " link ", comment)
    comment = re.sub(r"\b\d+(?:\.\d+)?\s+", "", comment)  # remove numbers

    # Remove punctuation from comment
    comment = "".join([c for c in comment if c not in punctuation])

    return comment


@app.get("/info")
async def model_info():
    """Return model information, version, how to call"""
    return {"name": "sentiment analysis", "version": "0.1"}


@app.get("/predict-sentiment")
async def predict_sentiment(comment: str, model_path=None):
    """
    A simple function that receive a comment and predict the sentiment.
    :param comment:
    :return: prediction, probabilities
    """
    # clean the review
    cleaned_comment = get_clean_comment(comment)

    # load the model
    model_obj = MultiNB()

    # predict the sentiment
    result = model_obj.predict(cleaned_comment)

    # return the result
    return result
