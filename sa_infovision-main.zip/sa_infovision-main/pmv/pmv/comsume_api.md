[**How to run:**]
1. Install requirements file by executing folowing command
- pip install -r requirements.txt
2. run following command 
- uvicorn main:app --reload
3. navigate to following address in your browser and enjoy!!!
- http://127.0.0.1:8000/docs