# Sentiment Analysis Model Assignment Document

## Introduction

The primary objective of this assignment is to develop a sentiment analysis model capable of accurately categorizing text data into positive, negative, or neutral sentiments.

## Assignment Objectives

The key objectives of this assignment include:

- Developing a sentiment analysis model using NLP techniques.
- Performing data collection and preprocessing to prepare the text data for model training.
- Selecting an appropriate NLP model for sentiment analysis.
- Training the selected model on preprocessed data and evaluating its performance.
- Deploying the model as a web service or API, if feasible, to demonstrate real-world usability.
- Creating comprehensive documentation detailing the entire process.

## Assignment Instructions

### Data Collection

The dataset has already been provided, containing two attributes: 'comments' and 'label' (which represents the sentiment label). With a total of 41,144 records, the dataset is fully labeled, making it suitable for analysis.

### Data Preprocessing

#### Exploratory Data Analysis (EDA)

Exploratory Data Analysis (EDA) is an essential step in data analysis, aimed at gaining insights and understanding the characteristics of the dataset. In the context of sentiment analysis, EDA helps identify patterns and trends in the text data that are crucial for building an accurate model.

During the EDA process, I initially utilized a word count approach to analyze the dataset. This approach is particularly relevant for sentiment analysis, as it considers all words in the text data, including stopwords, which can also contribute to sentiment expression.

The key findings from the word analysis are as follows:

- I aimed to ensure that sentences with minimal sentiment contain a minimum of 5-8 words, as shorter sentences may not provide sufficient context for sentiment analysis.
- The mean word length across all comments is calculated to be 24 words.
- The dataset includes a wide range of comment lengths, with the longest comment containing 402 words and the shortest comment consisting of only 1 word.
- Notably, at least 25% of the comments contain 9 words or more, indicating the presence of substantial text data necessary for effectively capturing sentiment nuances.
- Also observed that single-word comments may pose a challenge for the model in accurately deriving sentiment. Therefore, all such records were removed.

##### After EDA I observed that data has approximately:

- 22,156 negative comments
- 18,942 positive comments
- 36 neutral comments

> **Note:** There are more negative samples than the others.

> **Note:** I utilized word count analysis and observed that, upon viewing the word cloud, some negative words were represented in the positive cloud. 
I considered the given labels as golden labels for the model.


These findings provide valuable insights into the distribution and characteristics of the text data, which will inform subsequent steps in the sentiment analysis model development process.


### Model Selection

1. In modeling, we can employ standard machine learning (ML) techniques such as Naive Bayes or Support Vector Machine (SVM). 
In this approach, I perform text preprocessing tasks such as text cleanup, stemming, and splitting the data into training and test sets for evaluation.

2. Another advanced approach is to fine-tune pre-trained deep learning models.

3. The main difference between these two techniques is that the latter better captures the natural language nuances of the comments and accurately identifies sentiment.
   
   For testing purposes, both modeling approaches were evaluated:
   
   - Naive Bayes
   - BERT (Bidirectional Encoder Representations from Transformers) - pre-trained and fine-tuned on tweet data


### Model Training

Two important parts of model training are:

- test_size: I have used 0.2 as test size meaning that 20% i.e. ~ 8227 records of the data will be used for testing, while the remaining 80% ~ 32907 records  will be used for training.

- random_state: This is a random seed used for reproducibility. It ensures that the data split will be the same each time the code is run, allowing for consistent results.


### Evaluation

For the Multinomial Naive Bayes algorithm, the model accuracy is calculated as follows:
- F1 score: 64%
- Accuracy: 58%

For more details, please refer to the notebook.

> **Note:** Based on the analysis and hypothesis, it is suggested that if we train the model with the given data, we could achieve some remarkable accuracy and F1 score. However, it should be noted that the data labels were not correct.

> **Note:** I attempted to utilize pre-trained models; however, due to memory limitations (requiring GPU), I was unable to perform training of such models locally.

### Deployment

#### Deployment using FastAPI

In deploying the sentiment analysis model, I leverage the power of FastAPI, high-performance web framework for building APIs with Python. FastAPI provides several advantages, including:

- **High Performance:** FastAPI is built on top of Starlette and Pydantic, making it one of the fastest Python frameworks available.
- **Automatic Documentation:** FastAPI automatically generates interactive API documentation using Swagger UI, enabling easy exploration and consumption of the API endpoints.
- **Type Safety:** FastAPI utilizes Python type hints for automatic validation, serialization, and documentation of API endpoints, ensuring robustness and clarity of code.
- **Async Support:** FastAPI natively supports asynchronous programming, allowing for efficient handling of concurrent requests and improving scalability.
- **Easy Deployment:** FastAPI applications can be easily deployed using ASGI servers like Uvicorn or Hypercorn, facilitating seamless deployment to production environments.

To deploy the sentiment analysis model as an API service, I have chosen FastAPI from Python. 
Sample code for deploying the model is available in the code directory of the repository.

- As future scope, we can leverage pre-trained models to fine-tune the sentiment analysis model for improved accuracy. 
- Label refinement is also required for the dataset to ensure better training outcomes. 
- Additionally, for deployment, we can consider a Dockerized, cloud-agnostic solution to leverage the power of Docker for scalable and efficient deployment in various cloud environments.
- For version control I'll use GIT which  allows you to keep track of changes made to your code over time. 

## Conclusion

- Based on the analysis of the data and the model I constructed, it is evident that training the model with the provided data has the potential to achieve remarkable accuracy and F1 score. However, it is essential to acknowledge that the data labels were not correct, which may hinder the improvement of model accuracy.

- Deploying the model as an API service will be beneficial for easy consumption of the API and integration into applications. This will enhance accessibility and usability, ultimately facilitating broader utilization of the sentiment analysis model.